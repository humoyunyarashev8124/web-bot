export function getData() {
    return [
        {
            title: "Mushuk",
            price: "10",
            Image: "https://static8.tgstat.ru/channels/_0/de/de3ea0c33ff85b85934d670794589286.jpg",
            id: 1
        },
        {
            title: "Kuchuk",
            price: "10",
            Image: "https://vatanda.com/uploads/posts/2018-06/1529356022_it.jpg",
            id: 2
        },
        {
            title: "Ot",
            price: "10",
            Image: "https://upload.wikimedia.org/wikipedia/commons/thumb/f/f8/Pernod_Al_Ariba_0046b.jpg/640px-Pernod_Al_Ariba_0046b.jpg",
            id: 3
        },
        {
            title: "ilon",
            price: "10",
            Image: "https://static.xabar.uz/crop/2/2/720_460_95_222754302.jpg",
            id: 4
        },
        {
            title: "Jaguar",
            price: "10",
            Image: "https://upload.wikimedia.org/wikipedia/commons/0/0a/Standing_jaguar.jpg",
            id: 5
        },
        {
            title: "qoplon",
            price: "10",
            Image: "https://xabar.uz/static/crop/2/3/920__95_2333131198.jpg",
            id: 6
        },
    ]
}